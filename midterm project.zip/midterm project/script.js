function showMsg() {
  alert("Button clicked!");
}

function subscribe() {
  alert("Thank you for subscribing!");
}
